<?php

    
if( $_SESSION['auth_role'] !="2"){
    $_SESSION['message']="You are not Autherize as super Admin for this page";
    header("Location: index.php");
    exit(0);
}

?>