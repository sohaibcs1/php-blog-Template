<footer class=" bg-dark text-center text-lg-start">
  <!-- Copyright -->
  <div class="text-center p-3 text-white" >
    © 2022 Copyright
    <!-- <a class="text-dark" href="https://mdbootstrap.com/">MDBootstrap.com</a> -->
  </div>
  <!-- Copyright -->
</footer>



<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/script.js"></script>


</body>
</html>
