<?php 
include('authentication.php');
include('includes/header.php');
?>

<div class="container-fluid px-4">
           
            <div class="row mt-4">   
 
            <div class=".col-md-12 ">

                <?php include('message.php'); ?>

                <div class="card">
                    <div class="card-header">
                        <h4>Affected Clients
                            <a href="index.php" class="btn btn-danger float-end">Back</a>
                        </h4>
                    </div>
                    <div class="card-body">


                    <table id="myDataTable" class="table table-striped" style="width:100%">
        <thead>
            <tr>
                <th>client Number</th>
                <th>Device Name</th>
                <th>First Seen</th>
                <th>Last Seen</th>
                <th>IP</th>
                <th>Country</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>Samesung</td>
                <td>2:30 AM 4/25/22</td>
                <td>2:35 AM 4/25/22</td>
                <td>192.168.0.5</td>
                <td>India</td>
            </tr>
            <tr>
            <td>2</td>
                <td>Samesung</td>
                <td>2:30 AM 4/25/22</td>
                <td>2:35 AM 4/25/22</td>
                <td>192.168.0.5</td>
                <td>India</td>
            </tr>
            <tr>
            <td>3</td>
                <td>Samesung</td>
                <td>2:30 AM 4/25/22</td>
                <td>2:35 AM 4/25/22</td>
                <td>192.168.0.5</td>
                <td>India</td>
            </tr>
            <tr>
            <td>4</td>
                <td>Samesung</td>
                <td>2:30 AM 4/25/22</td>
                <td>2:35 AM 4/25/22</td>
                <td>192.168.0.5</td>
                <td>India</td>
            </tr>
            <tr>
            <td>5</td>
                <td>Samesung</td>
                <td>2:30 AM 4/25/22</td>
                <td>2:35 AM 4/25/22</td>
                <td>192.168.0.5</td>
                <td>India</td>
            </tr>
            <tr>
            <td>6</td>
                <td>Samesung</td>
                <td>2:30 AM 4/25/22</td>
                <td>2:35 AM 4/25/22</td>
                <td>192.168.0.5</td>
                <td>India</td>
            </tr>
        </tbody>
        
    </table>

                    </div>

</div>
</div>

</div>

</div>

<?php
include('includes/footer.php');
include('includes/scripts.php');
?>