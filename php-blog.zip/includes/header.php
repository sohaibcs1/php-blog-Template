
<!DOCTYPE html>
<html>
<head>
  <!-- <title>Free Software Download</title> -->

  <title> <?php if(isset($page_title)){ echo "$page_title";} else{echo "Free Software Download";} ?> </title>
  <meta name="description" content="<?php if(isset($meta_description)){ echo "$meta_description";}  ?>" />
  <meta name="keywords" content="<?php if(isset($meta_keywords)){ echo "$meta_keywords";}  ?>" />
  <meta name="auther" content="Free Software Download" />

  <link rel="stylesheet" href="assets/css/bootstrap.min.css"></link>
  <link rel="stylesheet" href="assets/css/custom.css"></link>
</head>
<body>

