<?php

session_start();
include('admin/config/dbcon.php');


?>