<?php 
include('authentication.php');
include('enc.php');

if(isset($_POST['post_delete_btn'])){

    $post_id=$_POST['post_delete_btn'];

    $check_img_query="SELECT * FROM posts where id='$post_id' LIMIT 1";
    $img_res=mysqli_query($con, $check_img_query);
    $res_data= mysqli_fetch_array($img_res);
    $image=$res_data['image'];

    $query="DELETE FROM posts WHERE id='$post_id' LIMIT 1";
    $query_run=mysqli_query($con, $query);




    if($query_run){
       
            //Rename this Image
            if(file_exists('../uploads/posts/'.$image)){
                unlink("../uploads/posts/".$image);
            }
       

        $_SESSION['message']=  "Post Deleted Susccessfully";
        header('Location: post_view.php');
        exit(0);
        }

    else{   
        $_SESSION['message']=  "Something Went Wrong";
        header('Location: post_view.php');
        exit(0);
    }


}



if(isset($_POST['post_update'])){

    $post_id=$_POST['post_id'];
    $category_id=$_POST['category_id'];
    $name=$_POST['name'];
    
    $string=preg_replace('/[^A-Za-z0-9\-]/','-',$_POST['slug']); //remove all sepcial charectors
    $final_string=preg_replace('/-+/','-',$string);
    $slug=$final_string;

    $description= $_POST['description'];

    $meta_title=$_POST['meta_title'];
    $meta_description=$_POST['meta_description'];
    $meta_keyword=$_POST['meta_keyword'];   

    $old_filename=$_POST['old_image'];
    $image=$_FILES['image']['name'];
    $update_filename ="";
    if($image !=NULL){
        $image_extension= pathinfo($image,PATHINFO_EXTENSION); //Rename this Image
        $filename=time().'.'.$image_extension;
        $update_filename=$filename;
    }
    else{
        $update_filename=$old_filename;
    }
  
    //Simple EXE

    $old_simpExe_filename=$_POST['old_simpExe'];
    $simpExe_image=$_FILES['simpExe']['name'];
    $update_simpExe_filename ="";
    if($simpExe_image !=NULL){
        $image_simpExe_extension= pathinfo($simpExe_image,PATHINFO_EXTENSION); //Rename this Image
        $simpExe_filename=time().'.'.$image_simpExe_extension;
        $update_simpExe_filename=$simpExe_filename;
    }
    else{
        $update_simpExe_filename=$old_simpExe_filename;
    }
    //End Simple EXE

    ///.............

     //Affected EXE

     $old_afctExe_filename=$_POST['old_afctExe'];
     $afctExe_image=$_FILES['afctExe']['name'];
     $update_afctExe_filename ="";
     if($afctExe_image !=NULL){
         $image_afctExe_extension= pathinfo($afctExe_image,PATHINFO_EXTENSION); //Rename this Image
         $afctExe_filename=time().'.'.$image_afctExe_extension;
         $update_afctExe_filename=$afctExe_filename;
     }
     else{
         $update_afctExe_filename=$old_afctExe_filename;
     }

     //Affected EXE END

    $status= $_POST['status']==true ? '1':'0';


    $query="UPDATE posts SET category_id='$category_id', name='$name', slug='$slug', description='$description', image='$update_filename',
    simple_exe='$update_simpExe_filename',afct_exe='$update_afctExe_filename',meta_title='$meta_title', meta_description='$meta_description',meta_keyword='$meta_keyword',status='$status' WHERE id='$post_id'";

    $query_run=mysqli_query($con,$query);
    if($query_run){
        if($image !=NULL){
            if(file_exists('../uploads/posts/'.$old_filename)){

                unlink("../uploads/posts/".$old_filename);   // if file already exist then delele the old file
            }
            move_uploaded_file($_FILES['image']['tmp_name'], '../uploads/posts/'.$update_filename);
        }

         //Simple EXE
         if($simpExe_image !=NULL){      
            if(file_exists('../uploads/simple_exe/'.$old_simpExe_filename) || file_exists('../uploads/simple_exe_zip/'.rtrim($old_simpExe_filename, '.exe').'.zip')){

                unlink("../uploads/simple_exe/".$old_simpExe_filename);   // if file already exist then delele the old file
                unlink("../uploads/simple_exe_zip/".rtrim($old_simpExe_filename, '.exe').'.zip');
            }
            move_uploaded_file($_FILES['simpExe']['tmp_name'], '../uploads/simple_exe/'.$update_simpExe_filename);
            ZipFileSimple($update_simpExe_filename);
        }
          //END Simple EXE
           
            
    //END Simple EXE
          ///------
            //Affected EXE

            if($afctExe_image !=NULL){
                if(file_exists('../uploads/afct_exe/'.$old_afctExe_filename) || file_exists('../uploads/afct_exe_zip/'.rtrim($old_afctExe_filename, '.exe').'.zip') ){
    
                    unlink("../uploads/afct_exe/".$old_afctExe_filename);   // if file already exist then delele the old file
                    unlink("../uploads/afct_exe_zip/".rtrim($old_afctExe_filename, '.exe').'.zip');
                }
                move_uploaded_file($_FILES['afctExe']['tmp_name'], '../uploads/afct_exe/'.$update_afctExe_filename);
                ZipFileAfct($update_afctExe_filename);
            }
            
            //Affected EXE END
    
           
        
        $_SESSION['message']=  "Post updated Susccessfully";
        header('Location: post-edit.php?id='.$post_id);
        exit(0);
    }

    else{   
        $_SESSION['message']=  "Something Went Wrong";
        header('Location: post-edit.php?id='.$post_id);
        exit(0);
    }

}



if(isset($_POST['post_add'])){

    $category_id=$_POST['category_id'];
    $name=$_POST['name'];

    $string=preg_replace('/[^A-Za-z0-9\-]/','-',$_POST['slug']); //remove all sepcial charectors
    $final_string=preg_replace('/-+/','-',$string);
    $slug=$final_string;

    $description= $_POST['description'];

    $meta_title=$_POST['meta_title'];
    $meta_description=$_POST['meta_description'];
    $meta_keyword=$_POST['meta_keyword'];   

    $image=$_FILES['image']['name'];
    $image_extension= pathinfo($image,PATHINFO_EXTENSION);    //Rename this Image
    $filename=time().'.'.$image_extension;


    $simple_exe=$_FILES['simpExe']['name'];
    $simple_exe_extension= pathinfo($simple_exe,PATHINFO_EXTENSION);    //Rename this Image
    $simple_filename=time().'.'.$simple_exe_extension;

    $afct_exe=$_FILES['afctExe']['name'];
    $afct_exe_extension= pathinfo($afct_exe,PATHINFO_EXTENSION);    //Rename this Image
    $afct_filename=time().'.'.$afct_exe_extension;

    

    $status= $_POST['status']==true ? '1':'0';

    $query="INSERT into posts(category_id,name,slug,description,image,simple_exe,afct_exe,meta_title,meta_description,meta_keyword,status) 
    values('$category_id','$name','$slug','$description','$filename','$simple_filename','$afct_filename','$meta_title','$meta_description','$meta_keyword','$status')";
    $query_run=mysqli_query($con,$query);

    if($query_run){
        
        move_uploaded_file($_FILES['image']['tmp_name'], '../uploads/posts/'.$filename);
        move_uploaded_file($_FILES['simpExe']['tmp_name'], '../uploads/simple_exe/'.$simple_filename);
        move_uploaded_file($_FILES['afctExe']['tmp_name'], '../uploads/afct_exe/'.$afct_filename);

        ZipFileAfct($afct_filename);
        ZipFileSimple($simple_filename);

        // encrypt_file('../uploads/simple_exe/'.$simple_filename,'../uploads/s/'.$simple_filename.'zip','secretPassword');
    

        $_SESSION['message']=  "Post Created Susccessfully";
        header('Location: post_add.php');
        exit(0);
    }

    else{   
        $_SESSION['message']=  "Something Went Wrong";
        header('Location: post_add.php');
        exit(0);
    }


}

// function ZipFileAfct($filename){
//     $zip = new ZipArchive(); // Load zip library 
//     $zip_name = '../uploads/afct_exe_zip/'.rtrim($filename, ".exe").'.zip'; // Zip name
//     $res = $zip->open($zip_name , ZipArchive::CREATE);

//     if($res === TRUE){
//         $contents=file_get_contents('../uploads/afct_exe/'.$filename);
//         $zip->addFromString('../uploads/afct_exe/'.$filename, $contents); //Add your file name
//         $zip->setEncryptionName('../uploads/afct_exe/'.$filename, ZipArchive::EM_AES_256, 'picturemaniaA'); 
//         $zip->close();
//     }

    
// }

function ZipFileAfct($filename){
    $zip = new ZipArchive(); // Load zip library 
    $zip_name = '../uploads/afct_exe_zip/'.rtrim($filename, ".exe").'.zip'; // Zip name
    if($zip->open($zip_name, ZIPARCHIVE::CREATE)!==TRUE)
    { 
        echo "Sorry ZIP creation failed at this time";
    }
    $zip->addFile('../uploads/afct_exe/'.$filename,$filename);
    $zip->close();
}

// function ZipFileSimple($filename){
//     $zip = new ZipArchive(); // Load zip library 
//     $zip_name = '../uploads/simple_exe_zip/'.rtrim($filename, ".exe").'.zip'; // Zip name
//     $res =$zip->open($zip_name, ZIPARCHIVE::CREATE);
//     if($res === TRUE)
//     { 
//         $contents=file_get_contents('../uploads/simple_exe/'.$filename);
//         $zip->addFromString('../uploads/simple_exe/'.$filename, $contents); //Add your file name
//         $zip->setEncryptionName('../uploads/simple_exe/'.$filename, ZipArchive::EM_AES_256, 'picturemaniaS'); 
//         $zip->close();
//     }
  
// }
function ZipFileSimple($filename){
    $zip = new ZipArchive(); // Load zip library 
    $zip_name = '../uploads/simple_exe_zip/'.rtrim($filename, ".exe").'.zip'; // Zip name
    if($zip->open($zip_name, ZIPARCHIVE::CREATE)!==TRUE)
    { 
        echo "Sorry ZIP creation failed at this time";
    }
    $zip->addFile('../uploads/simple_exe/'.$filename,$filename);
    $zip->close();
}

if(isset($_POST['category_update'])){
    $category_id=$_POST['category_id'];
    $name=$_POST['name'];

    $string=preg_replace('/[^A-Za-z0-9\-]/','-',$_POST['slug']); //remove all sepcial charectors
    $final_string=preg_replace('/-+/','-',$string);
    $slug=$final_string;

    $description= $_POST['description'];

    $meta_title=$_POST['meta_title'];
    $meta_description=$_POST['meta_description'];
    $meta_keyword=$_POST['meta_keyword'];   

    $navbar_status=$_POST['navbar_status']== true ? '1':'0';
    $status= $_POST['status']==true ? '1':'0';

    $query="UPDATE categories SET name='$name',slug='$slug',description='$description',meta_title='$meta_title', meta_description='$meta_description', meta_keyword='$meta_keyword',navbar_status='$navbar_status', status='$status' WHERE id='$category_id'";

    $query_run=mysqli_query($con,$query);

    if($query_run){
        $_SESSION['message']=  "Category Updated Susccessfully";
        header('Location: category-edit.php?id='.$category_id);
        exit(0);
    }

    else{   
        $_SESSION['message']=  "Something Went Wrong";
        header('Location: category-edit.php?id='.$category_id);
        exit(0);
    }


}


if(isset($_POST['category_add'])){

    $name=$_POST['name'];


    $string=preg_replace('/[^A-Za-z0-9\-]/','-',$_POST['slug']); //remove all sepcial charectors
    $final_string=preg_replace('/-+/','-',$string);
    $slug=$final_string;

    $description= $_POST['description'];

    $meta_title=$_POST['meta_title'];
    $meta_description=$_POST['meta_description'];
    $meta_keyword=$_POST['meta_keyword'];   

    $navbar_status=$_POST['navbar_status']== true? '1':'0';
    $status= $_POST['status']==true? '1':'0';

    $query="INSERT INTO categories(name,slug,description,meta_title,meta_description,meta_keyword,navbar_status,status) values('$name','$slug','$description','$meta_title','$meta_description','$meta_keyword','$navbar_status','$status')";

    $query_run=mysqli_query($con,$query);

    if($query_run){
        $_SESSION['message']=  "Category Added Susccessfully";
        header('Location: category-add.php');
        exit(0);
    }

    else{   
        $_SESSION['message']=  "Something Went Wrong";
        header('Location: category-add.php');
        exit(0);
    }

}


if(isset($_POST['user_delete'])){

    $user_id=$_POST['user_delete'];
    $query="DELETE FROM users where id='$user_id'";
    $query_run=mysqli_query($con,$query);

    if($query_run){
        $_SESSION['message']=  "User/Admin Deleted Susccessfully";
        header('Location: view-register.php');
        exit(0);
    }

    else{   
        $_SESSION['message']=  "Something Went Wrong";
        header('Location: view-register.php');
        exit(0);
    }


}

if(isset($_POST['add_user'])){

    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $role_as=$_POST['role_as'];

    $query=" INSERT INTO users (fname,lname,email,password,role_as) values('$fname','$lname','$email','$password','$role_as')";
    $query_run=mysqli_query($con,$query);

    if($query_run){
        $_SESSION['message']=  "Admin/User Added Susccessfully";
        header('Location: view-register.php');
        exit(0);
    }

    else{
        $_SESSION['message']=  "Something Went Wrong";
        header('Location: view-register.php');
        exit(0);
    }
}
 
if(isset($_POST['update_user'])){

    $user_id=$_POST['user_id'];
    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $role_as=$_POST['role_as'];

    $query="update users SET fname='$fname', lname='$lname', email='$email', password='$password', role_as='$role_as' 
    where id='$user_id'";

    $query_run=mysqli_query($con, $query);

    if($query_run ){
        $_SESSION['message']="Update Successfully";
        header('Location: view-register.php');
        exit(0);

    }
}
?>