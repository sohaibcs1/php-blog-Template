<?php
include('lib/dbip-client.class.php');


    function getVisIPAddr(){
    //check for shared internet
    if(!empty($_SERVER["HTTP_CLIENT_IP"])){

        $IP=$_SERVER["HTTP_CLIENT_IP"];
    }
    else if(!empty($_SERVER["HTTP_X_FORWARDED_FOR"])){
        //check for ip adress proxcy server
        $IP=$_SERVER["HTTP_X_FORWARDED_FOR"];
    }
    else{
        $IP=$_SERVER["REMOTE_ADDR"];
    }

    return $IP;
}

function getCountry(){

        // Store the IP address
    $ipAddress = getVisIPAddr();
    // echo $ipAddress;
    //49.136.0.0
    // Lookup IP address information
    $addrInfo = DBIP\Address::lookup($ipAddress);
    
    // Display results
    return $addrInfo->countryCode;
    // echo "Visitor country name : {$addrInfo->countryName}<br />";

}


function country(){
    $url = "http://ip-api.com/php/".getVisIPAddr()."?fields=countryCode";   
    $ch = curl_init();   
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);   
    curl_setopt($ch, CURLOPT_URL, $url);   
    $res = curl_exec($ch);   
    $data=substr($res,-5,-3);
    return $data;
}

?>
