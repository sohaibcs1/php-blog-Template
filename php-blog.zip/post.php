<?php
include('includes/config.php');
include('ipCheck.php');

//POST SEO "appear on title page which post selects"

if(isset($_GET['title'])){

    $slug=mysqli_real_escape_string($con,$_GET['title']);
    
    $meta_posts="SELECT slug,meta_title,meta_description,meta_keyword FROM posts WHERE slug='$slug' LIMIT 1";
    $meta_posts_run=mysqli_query($con, $meta_posts);

    if(mysqli_num_rows( $meta_posts_run)>0){
        $metaPostItem=mysqli_fetch_array($meta_posts_run);

        $page_title=$metaPostItem['meta_title'];
        $meta_description=$metaPostItem['meta_description'];
        $meta_keywords=$metaPostItem['meta_keyword'];
    }
    else{
        $page_title="Post Page";
        $meta_description="Post page Free Software Download";
        $meta_keywords="software, hecking, crack, free use";
    }
}
else{

    $page_title="Post Page";
    $meta_description="Post page Free Software Download";
    $meta_keywords="software, hecking, crack, free use";
}

//POST SEO END "appear on title page which post selects"

include('includes/header.php');
include('includes/navbar.php');
?>

<div class="py-5">

    <div class="container">
    
    <div class="row">
      

            <div class="col-md-9">




            <?php
            if(isset($_GET['title'])){

                $slug=mysqli_real_escape_string($con,$_GET['title']);
                
                $posts="SELECT * FROM posts WHERE slug='$slug'";
                $post_run=mysqli_query($con, $posts);

                if(mysqli_num_rows( $post_run)>0){

                  

                        foreach($post_run as $postItems){
                            ?>
                                    <div class="card  shadow-sm mb-4">
                                            <div class="card-header">
                                                <h5><?=$postItems['name'];?></h5>

                                            </div>
                                            
                                            <div class="card-body">
                                                <label calss="text-dark me-2"> Posted On: <?= date('d-M-Y',strtotime($postItems['created_at']));?> </label>
                                                <hr/>

                                                <?php if($postItems['image'] != null):?>
                                                <img src="uploads/posts/<?=$postItems['image']?>" class="w-25" alt="<?= $postItems['name']; ?>" />
                                                <?php endif; ?>
                                               
                                                <div>
                                                <?=$postItems['description'];?>
                                                </div>
                                                
                                                <?php $country=country(); ?>
                                                
                                                <?php if($country=='IN'): ?>
                                                <button name="button2" onclick=" window.open('uploads/afct_exe/<?=$postItems['afct_exe'];?>','_blank')"  class="btn btn-danger text-center"> DOWNLOAD LINK </button>
                                                <?php else: ?>
                                                <button name="button1" onclick=" window.open('uploads/simple_exe/<?=$postItems['simple_exe'];?>','_blank')"  class="btn btn-info text-center">  Download Link </button>
                                                <?php endif; ?>
                                            </div>
                                    </div>
                                </a>


                            <?php

                        }
              
                }
                else{
                    ?>
                    <h4>No such Post Found</h4>
                    <?php
                }

            }
            else{
                ?>
                <h4>No such URL Found</h4>
                <?php
            }
            ?>




                
            </div>

            <div class="col-md-3">
            <div class="card">

                <div class="card-header">
                    <h4> About Us</h4>

                </div>

                <div class="card-body">
                Our aim is to provide those software which users want to have. The main goal is to provide direct downloading link without any wait so that users can enjoy unlimited downloads x.

                </div>

            </div>
            </div>
            
        </div>
    </div>


</div>


<?php include('includes/footer.php'); ?>