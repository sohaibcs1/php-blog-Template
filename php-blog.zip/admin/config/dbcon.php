<?php
// $host="185.141.25.244";
// $username="picturem_soft12gr";
// $password="?onGp8JUP0Gz";
// $database="picturem_software123";

$host="localhost";
$username="root";
$password="";
$database="appBlog";

$con = mysqli_connect("$host","$username","$password","$database");

if(!$con){
    header("Location: ../errors/dberror.php");
    die();
}
?>